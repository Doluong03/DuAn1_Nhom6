/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poly.it17326.group6.service.impl;

import com.poly.it17326.group6.domainmodel.TaiKhoan;
import com.poly.it17326.group6.repository.ChangePasswordRepository;
import com.poly.it17326.group6.service.ChangePasswordService;

/**
 *
 * @author Tung Anh
 */
public class ChangePasswordImpl implements ChangePasswordService{

    ChangePasswordRepository change = new ChangePasswordRepository();
    @Override
    public TaiKhoan getPassword(String MatKhau) {
        return change.getPassword(MatKhau);
    }

    @Override
    public String changePassword(String ma, String MatKhau) {
        return change.changePassword(ma, MatKhau);
    }

    @Override
    public TaiKhoan getMa(String ma) {
        return change.getMa(ma);
    }
    
}
