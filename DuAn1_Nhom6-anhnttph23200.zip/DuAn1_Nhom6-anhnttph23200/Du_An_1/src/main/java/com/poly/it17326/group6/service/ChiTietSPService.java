/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.poly.it17326.group6.service;

import com.poly.it17326.group6.response.ChiTietSpResponse;
import java.util.ArrayList;

/**
 *
 * @author 123
 */
public interface ChiTietSPService {
    
    public ArrayList<ChiTietSpResponse> getAll();
    
    public ArrayList<ChiTietSpResponse> getTimKiem(String ma);
}
